﻿using System;
using System.Threading;
using System.Diagnostics;

/*
 * This has been created by gruffy.wright@gmail.com with the intended use in the classroom to explain programming concepts
 * Care should be taken not to confuse this with open source material as it may have proprietary ownership implications with South Devon College 2015
 * The code is free to view and the data structures, method implementations are commonly found and can be easily abstracted.
 *  What this demonstrates is that with just over 500 lines of code, we can produce a fairly convincing adventure that feels relatively organic.
 *  This is a prototype in many ways as much is NOT finished and it could benefit greatly from better management through classification.
 * However, the starting blocks are definately in place to create something interesting from here, whether you have coding experience or not
*/
namespace TextAdventureGruffy
{
	class MainClass
	{
		public static bool Started = false;
		public static bool northDungeon, eastDungeon, southDungeon, westDungeon, inDungeon, hasMetTheGneether = false;
		public static int Direction = 0;
		public static string currentDirection = " ";
		public static string currentDungeon = " ";
		public static string Input = " ";
		public static string Name = " ";
		public static int darkManaOrbs = 0;
		public static int lightManaOrbs = 0;
		public static int travelStatus = 0;
		public static int dungeonsVisited = 0;
		public static int steps = 0;
		public static int totalSteps = 100;
		public static int countCase13 = 0;
		public static ConsoleKeyInfo CKI;
		public static int[] DirectionCounter = new int[4];
		public static Random Rand;

		public static void Init()
		{
			Rand = new Random();
			DirectionCounter = new int[4]{0,0,0,0};
			Started = false;
			Direction = 0;
			Input = " ";
			Name = " ";
			darkManaOrbs = 0;
			lightManaOrbs = 0;
			travelStatus = 0;
			inDungeon = false;
			dungeonsVisited = 0;
			steps = 0;
			totalSteps = 100;
			countCase13 = 0;
			hasMetTheGneether = false;
			currentDungeon = "None";
			currentDirection = "None";
		}
		private static void ChanceDeath( int option)
		{
			Console.Clear ();
			Console.Write ("press T key to throw the dice");
			CKI = Console.ReadKey ();
				if (CKI.Key == ConsoleKey.T) 
				{
					if (option == 0) 
					{//Random r = new Random ();
						int randOutcome = Rand.Next (1, 6);
						if (randOutcome % 2 == 1) 
						{
							Console.Clear ();
							Console.WriteLine ("\tYou made it this time");
							Console.WriteLine ("\n\nYou rolled a " + randOutcome + "\n\n");
							Thread.Sleep (2000);
							Step ();
						} 
						else 
						{
							Console.Clear ();
							Console.WriteLine ("\tYou DIED, the END");
							Console.WriteLine ("\n\nYou rolled a " + randOutcome + "\n\n");
							Thread.Sleep (2000);

							GameOver ();
						}
					} 
					if(option == 1) 
					{
						int randOutcome = Rand.Next (1, 6);

						if (randOutcome % 2 == 0) 
						{
							Console.Clear ();
							Console.WriteLine ("\tYou made it this time");
							Console.WriteLine ("\n\nYou rolled a " + randOutcome + "\n\n");
							Thread.Sleep (2000);
							Step ();
						} 
						else
						{
							Console.Clear ();
							Console.WriteLine ("\tYou DIED, the END");
							Console.WriteLine ("\n\nYou rolled a " + randOutcome + "\n\n");
							Thread.Sleep (2000);

							GameOver ();
						}
					}
			}
		}
					
		private static void CheckRoom()
		{			
			int currentStep = steps;

			//randomizer to given feel of procedural play each time
			int result = Rand.Next(0, currentStep);
			//debug
			Console.WriteLine ("switching this number "+  result);
			if(result == 13)
			{
				countCase13 += 1;
				if(countCase13 > 1)
				{
					hasMetTheGneether = true;
					result = Rand.Next(0, currentStep);
				}
			}
			//debugging only to curb currentSTep case sattements - these could grow bigger you see :)
			if(currentStep > 15)
			{
				result = Rand.Next(0, 16);
					//Console.WriteLine ("\nDEBUG NOTICE TO DEVELOPER...\nresult has passed recording 15 paces"
					//+ "\nwe will reduce result to stay within our current case options for the switch which is.. "
					//+ "\n15, so we ensure it never goes beyond that from now on " + result);								
			}
			//uncomment the above to reveal a messgae to your self during dev to show we ahve curbed a number

			//each time a step is made an option is chosen to reveal to the player
			//this option may have further outcomes or not - this is the area to inject your own creativity with respect to 
			//outcomes for each move (not a perfect solution , but a working one)
			switch(result)
			{
			case 0:
				Console.Clear ();
				Console.WriteLine ("\nYou have met a wizard of light!\n");
				Console.WriteLine ("\nYou have gained 1 light mana orb\n");
				lightManaOrbs += 1;
				Console.WriteLine ("You have collected " + lightManaOrbs + " light Mana Orbs in your satchel");
				Thread.Sleep (1000);
				goto default;
				//break;

			case 1:
					Console.WriteLine ("There is a scary monster lurking in the shadows to the "+ currentDirection);
				break;
			case 2:
				Console.WriteLine ("There is something in the distance to the " + currentDirection);
				break;
			case 3:
				Console.WriteLine ("Are you sure you want to go further "+ currentDirection);
				break;
			case 4:
				if (!inDungeon) {
					Console.WriteLine ("You have found yourself in the " + currentDirection + " Dungeon");
					dungeonsVisited += 1;
					switch (currentDirection) {
					case "North":
						northDungeon = true;
						currentDungeon = currentDirection;
						inDungeon = true;
						Console.WriteLine ("the dungeon flag for " + currentDungeon + " is set to " + currentDungeon);
						break;
					case "East":
						eastDungeon = true;
						currentDungeon = currentDirection;
						inDungeon = true;
						Console.WriteLine ("the dungeon flag for " + currentDungeon + " is set to " + eastDungeon);
						break;
					case "South":
						southDungeon = true;
						currentDungeon = currentDirection;
						inDungeon = true;
						Console.WriteLine ("the dungeon flag for " + currentDungeon + " is set to " + southDungeon);
						break;
					case "West":
						westDungeon = true;
						currentDungeon = currentDirection;
						inDungeon = true;
						Console.WriteLine ("the dungeon flag for " + currentDungeon + " is set to " + westDungeon);
						break;
					default:
						currentDungeon = " ";
						break;
					}
				} 
				else 
				{
					Console.WriteLine ("You're still investigating the " + currentDungeon + " dungeon");
				}
				break;
			case 5:
				break;
			case 6:
				Console.WriteLine ("You have walked " + currentStep + " paces, towards " + currentDirection);
				if (currentStep >= 75 && currentStep < 100) {
					Console.WriteLine (Name + " the Master Traveller");
					travelStatus = 3;

				} 
				else 
				{
					Console.Clear ();
					Console.WriteLine ("\nYou have met a wizard of light!\n");
					Console.WriteLine ("\nYou have gained 1 light mana orb\n");
					lightManaOrbs += 1;
					Console.WriteLine ("You have collected " + lightManaOrbs + " Light Mana Orbs in your satchel");
					Thread.Sleep (1000);
					goto default;
				}	    
				break;
			case 7:
				Console.Clear ();
				Console.WriteLine ("Sorry you fell down a trap door and into some spikes");
				Console.WriteLine ("You must now throw an even to continue");
				Thread.Sleep (3000);
				ChanceDeath (1);
				break;
			case 8:
				break;
			case 9:
				if (inDungeon) 
				{
					Console.Clear ();
					Console.WriteLine ("You have left the " + currentDungeon + " Dungeon");
					Console.WriteLine ("You must now throw an odd to continue");
					inDungeon = false;
					Thread.Sleep (3000);
					ChanceDeath (0);
				} 
				else 
				{
					Console.WriteLine ("You passed a weary traveller who was not so lucky ");
				}
				break;
			case 10:				
				Console.WriteLine ("You have walked " + currentStep + " paces, towards " + currentDirection);
				if (currentStep >= 25 && currentStep < 30) {
					Console.WriteLine (Name + " the Traveller");
					travelStatus = 2;
				} 
				else 
				{
					Console.Clear ();
					Console.WriteLine ("\nYou have met a wizard of the darkest powers\n");
					Console.WriteLine ("\nYou have gained 1 dark mana orb\n");
					darkManaOrbs += 1;
					Console.WriteLine ("You have collected " + darkManaOrbs + " Dark Mana Orbs in your satchel");
					Thread.Sleep (1000);
					goto default;
				}	    
				break;
			case 11:
					//Console.WriteLine ("You have walked" + currentStep + "paces");
					Console.WriteLine ("You have walked " + currentStep + " paces, towards " + currentDirection);
					Console.WriteLine (Name + " ");
				break;
			case 12:
				goto case 11;

			case 13:
				//have we been here before
					if (hasMetTheGneether) 
					{
						Step ();
					} 
					else //no
					{
						Console.Clear ();
						Console.SetCursorPosition ((Console.WindowWidth / 2), (Console.WindowHeight / 2));
						Console.Write ("You have entered the Gneether\n");
						Console.Write ("A place for drifted souls and the\nempty husks of the dammned darkness\n");
						Console.Write ("'Beware the next choice yee make all who dare enter the nothing' is written on a plaque");
					}
				break;
			case 14:
				break;
			case 15:
				//Console.WriteLine ("You have walked" + currentStep + "paces")
				Console.WriteLine ("You have walked " + currentStep + " paces, towards " + currentDirection);
				if(currentStep < 25 && currentStep > 15)
				{
					Console.WriteLine (Name + " the wanderer");
					travelStatus = 1;
				}
				break;
			case 16:
				break;
			default: 
				//Console.Clear ();
				Console.WriteLine ("\n\nYou have walked " + currentStep + " paces, towards " + currentDirection);
				break;
			}
		}

		static void ShowStats ()
		{
			//Console.Clear ();
			Console.WriteLine ("Directions walked:");
			Console.Write ("Steps North: "+ DirectionCounter[0] + "| Steps East: "+ DirectionCounter[1] +
				"| Steps South: "+ DirectionCounter[2] + "| Steps West: "+ DirectionCounter[3]);
			Console.Write ("\nYou are currently facing the "+ currentDirection +" direction");
			Console.Write ("\n");
			Console.Write ("|Traveller Name: " + Name + " | Total Steps taken: " + steps +  " | Traveller Status: " + travelStatus + "\n");
			Console.Write ("Light Mana Orbs Collected: " + lightManaOrbs + " | Dark Mana Orbs Collected: " + darkManaOrbs);
			Console.Write("\nYou have encountered " + dungeonsVisited+ " Dungeons on your travels so far \n\n\n");
			Thread.Sleep (5000);
			//Console.Clear ();
			if(Started)
			{
				Step ();
			}

		}

		private static void Step()
		{

			string gaffer = ""; //not really verbose here !
			//won the game ?
			if(steps >= totalSteps)
			{
				GameWon ();
			}

			Console.WriteLine ("Press Enter to start walk mode");
			CKI = Console.ReadKey();
			Console.Clear ();
			Console.WriteLine ("Choose a direction with the N, S, E, W keys");
			while (CKI.Key != ConsoleKey.Q)
			{
				gaffer = (inDungeon) ? ("\n In the" + currentDungeon + " Dungeon ") : "";

				//Console.WriteLine ();
				CKI = Console.ReadKey();
				//need to switch the bools for being in a dungeon here
				switch(CKI.Key)
				{
				case ConsoleKey.N:
					currentDirection = "North";
					Console.WriteLine ("You have walked one pace in the " + currentDirection + gaffer);
						//go one north add a step to array pos 0 
					DirectionCounter [0] = DirectionCounter [0] + 1;
						
						steps++;
						CheckRoom ();
										break;
					case ConsoleKey.S:
					currentDirection = "South";
					Console.WriteLine ("You have walked one pace in the " + currentDirection + gaffer);
						//go one south add a step to array pos 2
						DirectionCounter[2] = DirectionCounter[2]+ 1;
						steps++;
						CheckRoom ();
										break;
					case ConsoleKey.W:
					currentDirection = "West";
					Console.WriteLine ("You have walked one pace in the " + currentDirection + gaffer);
						//go one west add a step to array pos 3
						DirectionCounter[3] = DirectionCounter[3]+ 1;
						
						steps++;
						CheckRoom ();
										break;
					case ConsoleKey.E:
					currentDirection = "East";
					Console.WriteLine ("You have walked one pace in the " + currentDirection + gaffer);
						//go one east add a step to array pos 1
						DirectionCounter[1] = DirectionCounter[1]+ 1;
						
						steps++;
						CheckRoom ();
										break;
					default:
						Console.Clear ();
						Console.WriteLine (" Choose a direction with N, S, E, W keys ");
										break;
				}

				if (CKI.Key == ConsoleKey.Q)
					//exit code todo
					return;

				if(CKI.Key == ConsoleKey.Spacebar)
				{
					ShowStats ();
				}
			}

			//char key = Console.KeyAvailable (Console.ReadKey ());
		}
		private static void StartGame()
		{
			Started = true;
			string answer = " ";
			Console.Clear ();
			Console.SetCursorPosition (5, 0);
			Console.WriteLine ("Will you help?\nType 'yes' to start adventure or 'exit' to leave safely...`\nTyping Anything else may not correctly close the portal you have opened here");
			answer = Console.ReadLine ();
			answer = answer.ToUpper ();
			if (answer == "YES") {
				while (answer != "EXIT") {
					Console.Clear ();
					Console.WriteLine ("what is your name traveller?\n");
					answer = Console.ReadLine ();
					answer = answer.ToUpper ();
					if (answer != "EXIT") {
						Console.Clear ();
						Console.WriteLine ("Welcome to the Dungeons of Gnarlgruff " + answer);
						//apply user name ato static string
						Name = answer;
						return; // go back to main
					} else {
						Environment.Exit (0);
					}
				}
			} else {
				//Init ();
				GameOver ();
			
			}
		}
		private static void GameOver()
		{
			if (Started && steps > 1) 
			{
				Console.Clear ();
				Console.WriteLine ("Thank you for your brave and noble attempt\nPlease return when you have honed you mana skills"
				+ "\n and mastered the art of adventuring");
				Thread.Sleep (5000);
				Console.Clear ();
				Console.WriteLine ("\tTO CONQUER...\n\n");
				Thread.Sleep (2000);

					Console.WriteLine (" \t\t|VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV| ");
					Console.WriteLine (" \t\t|  THE DUNGEONS OF GNARLGRUFF   | ");
					Console.WriteLine (" \t\t|              |  |             | ");
					Console.WriteLine (" \t\t|             /-**-\\            | ");
					Console.WriteLine (" \t\t|            /-****-\\           | ");
					Console.WriteLine (" \t\t|           /-******-\\          | ");
					Console.WriteLine (" \t\t|          /-********-\\         | ");
					Console.WriteLine (" \t\t|         /-**********-\\        | ");
					Console.WriteLine (" \t\t|===============================| ");
				Thread.Sleep (2000);
				Console.Clear ();
				Console.WriteLine ("\n\t\t\tGAME OVER !\n");
				Started = false;
				ShowStats ();
				Console.Write ("press Q to EXIT Game or Press R to restart adventure ");

				CKI = Console.ReadKey ();
				if (CKI.Key == ConsoleKey.Q) {
					Environment.Exit (0);
				}
				if(CKI.Key == ConsoleKey.R ){
					//
					//Started = false;
					//Init ();

					RunGame();
				}
			} 
			else 
			{
				Console.Clear ();
				Console.WriteLine ("Well... Thank you for your feeble attempt\nPlease return when you have become a true adventurer");
				Thread.Sleep (1500);
				Console.Clear ();
				Console.WriteLine ("Fair yee well in yonder adventures weakling");
				Thread.Sleep (2000);
				Console.Clear ();
				Console.WriteLine ("\nGAME OVER BEFORE YOU STARTED REALLY!" 
					+ "\n         YOUR SHAMEFUL COWARDICE CAUSED THE PORTAL TO FEED ON YOUR NEGATIVITY "
					+ "\n            AND THUS GREW BEYOND YOUR WORLD'S DIMENSIONAL COMPREHENSION"
					+ "\n                   THERE IS NOW NO WAY OF TURNING BACK THE CLOCK"
					+ "\n AND YOU WILL NEVER KNOW THE REAL REASON WHY HER HIGHNESS; THE PRINCESS DREW HAD TO DIE");
				Console.WriteLine ("\n");
				Console.WriteLine ("\nIT MAY ALSO BE WORTH MENTIONING THE GRATEFUL DEAD...\nTHEY WONT BE TOO GRATEFUL NOW YOUR NOT GOING TO SAVE THEM EITHER"
					+ "\n SLEEP WELL TONIGHT COWARDLY TRAVELLER... FOR YOUR BACK SHOULD STAY UNTURNED!\n");


				Console.Write ("press Q to Restart Game or Close the window to EXIT");
				CKI = Console.ReadKey ();
				if (CKI.Key != ConsoleKey.Q) {
					Environment.Exit (0);
				} 
				else 
				{
					//
					//Started = false;
					//Init ();
					RunGame();
				}
			}
		}
		private static void GameWon()
		{
			Console.Clear();
			Console.Write("You have travelled hard and conquered...");

			Console.WriteLine (" \t\t|VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV| ");
			Console.WriteLine (" \t\t|  THE DUNGEONS OF GNARLGRUFF   | ");
			Console.WriteLine (" \t\t|              |  |             | ");
			Console.WriteLine (" \t\t|             /-**-\\            | ");
			Console.WriteLine (" \t\t|            /-****-\\           | ");
			Console.WriteLine (" \t\t|           /-******-\\          | ");
			Console.WriteLine (" \t\t|          /-********-\\         | ");
			Console.WriteLine (" \t\t|         /-**********-\\        | ");
			Console.WriteLine (" \t\t|===============================| ");

			ShowStats ();
			Console.Write ("press Q to EXIT Game or Press R to restart adventure ");

			CKI = Console.ReadKey ();
			if (CKI.Key == ConsoleKey.Q) {
				Environment.Exit (0);
			}
			if(CKI.Key == ConsoleKey.R ){
				//
				//Started = false;
				//Init ();

				RunGame();
			}

		}
		private static void RunGame()
		{
			if (!Started) 
			{
				//string input = " ";
				while (Input != "HELLO") 
				{
					Console.Clear ();
					Console.WriteLine ("Hello");
					Input = Console.ReadLine ();
					Input = Input.ToUpper ();
					if (Input == "HELLO" ||Input == "HI"||Input == "HEY"||Input == "YO"|| Input == "WHASSUP") 
					{
						Input = " ";
						StartGame ();
						Step ();
					} 
					else 
					{
						Console.Clear ();
						Console.WriteLine ("No, you are not who I expected");
						System.Threading.Thread.Sleep (1500);
						Console.Clear ();
						Console.WriteLine ("GAME OVER");
						System.Threading.Thread.Sleep (2000);
						Init ();
					}
				}
			} 
		}
		public static void Main (string[] args)
		{
			Init ();
			RunGame ();
		}	
	}
}
